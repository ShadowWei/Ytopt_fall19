sourcefile = "/uufs/chpc.utah.edu/common/home/u1136450/ytopt/OpenMP_benchmark/27stencil.c"
sourcedir = "/uufs/chpc.utah.edu/common/home/u1136450/ytopt/OpenMP_benchmark"
outputdir = "/uufs/chpc.utah.edu/common/home/u1136450/ytopt/experiments/exp-7"
compileoptions = ""
